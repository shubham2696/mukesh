package com.beangate.employeereg;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText empName,empId;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        empName = findViewById(R.id.empName);
        empId = findViewById(R.id.empId);
        save = findViewById(R.id.save);
        Random rand = new Random();
        int id = rand.nextInt(1000000);
        final String idd = Integer.toString(id);
        empId.setText(idd);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(MainActivity.this,Main2Activity.class);
                i.putExtra("id",idd);
                startActivity(i);
            }
        });
       // Toast.makeText(this,"EmpId= "+id,Toast.LENGTH_SHORT).show();
       /* Intent i =new Intent(MainActivity.this,MainActivity2.class);
        startActivity(i);*/
    }
}
